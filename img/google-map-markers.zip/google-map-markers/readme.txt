Pixels Daily
=======================
Item: Google Map Markers PSD
Type: PSD
Author: Ali Asghar



Notes
=======================
These varied Google Map Makers are a fantastic set of resources to have in your design collection. They represent different things — a restaurant, telephone, gas, airport, rail station, and mechanic.

It's simple to implement these into an embedded Google Map!



Free Resource Licensing
=======================
All our free resources are licensed under a Creative Commons Attribution license. This license lets you distribute, remix, tweak, and build upon your work, even commercially, as long as you credit PixelsDaily for the original creation:

http://creativecommons.org/licenses/by/3.0/